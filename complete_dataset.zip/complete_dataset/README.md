# Parsight Meter Reading - Complete Fine-Tuning Dataset
# =====================================================

## Dataset Summary
- **Total examples**: 75
- **Train set**: 67 examples (train.jsonl) - 90%
- **Validation set**: 8 examples (val.jsonl) - 10%
- **Images**: 75 (meter_001.png to meter_075.png)

## Manufacturer Coverage (9 manufacturers)
| Manufacturer      | Count | % |
|-------------------|-------|---|
| Smart ALPS        | 26    | 35% |
| Raychem RPG       | 17    | 23% |
| Capital Innotech  | 12    | 16% |
| Itron GALLUS      | 9     | 12% |
| Zenner            | 7     | 9% |
| Capital           | 3     | 4% |
| IGL (Elster)      | 1     | 1% |

## Meter Types
| Type    | Count |
|---------|-------|
| G1.6    | 52    |
| G1.6MS  | 16    |
| G2.5MS  | 3     |
| C1.6MS  | 3     |
| BK-G1.6 | 1     |

## Utilities
- IGL (Indraprastha Gas Limited): 66
- Adani Gas: 9

## Data Format (JSONL)
Each line: {"image": "images/meter_XXX.png", "conversations": [...]}
- User: "Extract the meter reading from this gas meter image..."
- Assistant: JSON with meter_number, full_reading, billing_reading, meter_type, manufacturer, black_digits, red_digits

## Usage
1. Upload to Google Colab
2. Use with Qwen2-VL-2B fine-tuning notebook (Parsight_Meter_Reading_FineTune.ipynb)
3. Train for ~2-4 hours on A100 GPU
4. Download weights for local inference

## Files
- train.jsonl      - 67 training examples (shuffled)
- val.jsonl        - 8 validation examples
- all_data.jsonl   - all 75 examples (unsplit backup)
- images/          - 75 meter images (meter_001 to meter_075)
- README.md        - this file
